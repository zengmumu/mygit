import {HashRouter as Router,useHistory} from 'react-router-dom'

import RouterView from './router'
function App(){
  

  return <Router>
    <RouterView></RouterView>
  </Router>
}
export default App;